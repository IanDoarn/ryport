create function search_functions_for(search_text text, OUT schema_name name, OUT function_name name, OUT args text) returns SETOF record
LANGUAGE SQL
AS $$
SELECT n.nspname AS schema_name
      ,p.proname AS function_name
      ,pg_get_function_arguments(p.oid) AS args
FROM   (SELECT oid, * FROM pg_proc p WHERE NOT p.proisagg) p
JOIN   pg_namespace n ON n.oid = p.pronamespace
WHERE  n.nspname !~~ 'pg_%'
AND    n.nspname <> 'information_schema'
AND    pg_get_functiondef(p.oid) ~ search_text; --- this is what you are searching for
$$;
