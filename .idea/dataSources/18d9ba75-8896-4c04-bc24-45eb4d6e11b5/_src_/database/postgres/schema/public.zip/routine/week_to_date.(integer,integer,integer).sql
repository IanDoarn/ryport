create function week_to_date(in_year integer, in_week integer, in_dow integer) returns date
LANGUAGE plpgsql
AS $$
/*******************************************************************************
Function Name: week_to_date
In-coming Params:
– in_year INTEGER
– in_week INTEGER
– in_dow INTEGER
Description:
Takes the day of the week (0 to 6 with 0 being Sunday), week of the year, and
year. Returns the corresponding date.

Created On: 2011-12-21
Revised On: 2013-01-02
Author: Chris West
******************************************************************************/
DECLARE
BEGIN
RETURN to_timestamp('1 ' || in_year,'IW IYYY')::date + (COALESCE(in_dow, 1) + 6 ) % 7 + 7 * (in_week - 1);
END;
$$;
