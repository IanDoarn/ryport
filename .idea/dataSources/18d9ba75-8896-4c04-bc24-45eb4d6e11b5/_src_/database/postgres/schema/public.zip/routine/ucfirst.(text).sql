create function ucfirst(input_text text) returns text
LANGUAGE plperl
AS $$
  my ($input) = @_;
  return ucfirst lc $input;
  
$$;
