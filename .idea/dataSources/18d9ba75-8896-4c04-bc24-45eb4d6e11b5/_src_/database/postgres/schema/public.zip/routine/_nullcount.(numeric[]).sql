create function "_nullcount"(numeric[]) returns bigint
LANGUAGE plperl
AS $$
  my $inp = shift;

  my $count = 0;

  for my $val (@$inp) {
    $count++ unless defined ($val)
  }

  return $count;
$$;
