create function sms_eastern_time(sms_timestamp timestamp without time zone) returns timestamp without time zone
LANGUAGE plpgsql
AS $$
DECLARE
  est timestamp without time zone;
BEGIN

  select (sms_timestamp at time zone 'GMT+0')::timestamp without time zone
  into est;


  return est;
END;
$$;
