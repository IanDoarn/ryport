create function as400_date(input_date numeric) returns date
LANGUAGE plpgsql
AS $$
declare 
  year integer;
begin

  if input_date is null or input_date = 0 then
    return null;
  end if;

  return to_date(cast (19000000 + input_date as varchar), 'YYYYMMDD');
end;
$$;
