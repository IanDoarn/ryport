create function number2date(input integer) returns date
LANGUAGE plpgsql
AS $$
begin

  if (input > 999999) then

  else

  end if;

  return '2015-01-01';

end;
$$;
