create function extract_order_id(character varying) returns character varying
LANGUAGE plperl
AS $$
  my ($status_comment) = @_;
  my ($order_id) = $status_comment =~ /WO (\d+[A-Z]?),/;
  return $order_id;
$$;
