create function jde_date(jdejulian integer) returns timestamp without time zone
LANGUAGE plpgsql
AS $$
declare
  result timestamp;
  datestring varchar;
begin

  datestring = cast (jdejulian as varchar);

  result := case
    when jdejulian is null or jdejulian = 0 then null
    when jdejulian > 99999 then
      to_date('20' || substr (datestring, 2, 2) || right (datestring, 3), 'YYYYDDD')
    else
      to_date('19' || left (datestring, 2) || right (datestring, 3), 'YYYYDDD')
  end;

  return result;
end;
$$;
