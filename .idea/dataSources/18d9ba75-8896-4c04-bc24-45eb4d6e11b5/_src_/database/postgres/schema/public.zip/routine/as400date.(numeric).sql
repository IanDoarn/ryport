create function as400date(input_date numeric) returns date
LANGUAGE plpgsql
AS $$
declare 
  year integer;
begin

  if input_date is null or input_date = 0 then
    return null;
  end if;

  year := input_date::bigint / 10000 + 1900;
  return to_date(year || right(input_date::text, 4), 'YYYYMMDD');
end;
$$;
