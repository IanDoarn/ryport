create function inherited(search_text text, OUT parent name, OUT child name) returns SETOF record
LANGUAGE SQL
AS $$
SELECT p.relname AS parent,c.relname AS child
FROM
    pg_inherits JOIN pg_class AS c ON (inhrelid=c.oid)
    JOIN pg_class as p ON (inhparent=p.oid)
where p.relname ~ search_text
order by 1,2
;
 --- this is what you are searching for
$$;
