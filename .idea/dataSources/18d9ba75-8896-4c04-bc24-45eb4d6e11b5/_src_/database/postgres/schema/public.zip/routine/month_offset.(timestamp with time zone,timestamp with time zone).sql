create function month_offset(from_date timestamp with time zone, thru_date timestamp with time zone) returns double precision
LANGUAGE SQL
AS $$
select (extract (year from thru_date) - extract (year from from_date)) * 12 +
    extract (month from thru_date) - extract (month from from_date);
$$;
