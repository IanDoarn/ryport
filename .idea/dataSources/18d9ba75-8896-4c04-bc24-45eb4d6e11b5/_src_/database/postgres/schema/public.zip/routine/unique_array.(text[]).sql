create function unique_array(text[]) returns text
LANGUAGE plperl
AS $$
    my ($array_ref) = @_;
    return join '|', grep { !$already{$_}++ } @$array_ref;
$$;
