create function extract_persona_id(character varying) returns character varying
LANGUAGE plperl
AS $$
  my ($customer_po) = @_;
  $customer_po =~ s/_\d+$//;
  return $customer_po;
$$;
