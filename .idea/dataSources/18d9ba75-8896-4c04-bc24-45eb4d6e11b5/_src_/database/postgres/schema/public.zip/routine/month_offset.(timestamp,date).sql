create function month_offset(from_date timestamp without time zone, thru_date date) returns double precision
LANGUAGE SQL
AS $$
select (extract (year from thru_date) - extract (year from from_date)) * 12 +
    extract (month from thru_date) - extract (month from from_date);
$$;
