create function "_count_a"(text[]) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
    something1s alias for $1;
    something1 text;
    num int := 0;
  BEGIN
     FOREACH something1 IN array something1s
     LOOP
        num := num + length(regexp_replace(something1, '[^a]+', '', 'g'));
     END LOOP;
     RETURN num;
  END;
$$;
