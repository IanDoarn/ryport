create function excel_part(part_number text) returns text
LANGUAGE plperl
AS $$
  my ($input) = @_;
  if ($input =~ /[A-Za-z]/) {
    return $input;
  } elsif ($input =~ /^0+(\d+)$/) {          # 000123    => 123
    return $1;
  } elsif ($input =~ /^(\d+\.\d*)0+$/) {     # 1234.560  => 1234.56
    return $1 + 0;
  } elsif ($input =~ /^(\d+)\.$/) {          # 1234.     => 1234
    return $1 + 0;
  } elsif ($input =~ /^(\.\d+)$/) {          # .123400   => 0.1234
    return $1 + 0;
  } else {
    return $input;
  }  
  
$$;
