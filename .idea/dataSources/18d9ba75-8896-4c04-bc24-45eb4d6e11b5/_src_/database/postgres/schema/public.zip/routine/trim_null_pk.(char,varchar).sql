create function trim_null_pk(input_string character, default_output character varying) returns character varying
LANGUAGE plpgsql
AS $$
begin
  return
    case
      when input_string ~ '\S' then trim (input_string)
      else default_output
    end;
end;
$$;
