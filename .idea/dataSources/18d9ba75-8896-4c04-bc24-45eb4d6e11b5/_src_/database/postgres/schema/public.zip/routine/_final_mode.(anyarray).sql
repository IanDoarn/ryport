create function "_final_mode"(anyarray) returns anyelement
LANGUAGE SQL
AS $$
SELECT a
    FROM unnest($1) a
    GROUP BY 1 
    ORDER BY COUNT(1) DESC, 1
    LIMIT 1;
$$;
