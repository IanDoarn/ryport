create function std_deviation(VARIADIC inputs numeric[]) returns numeric
LANGUAGE plpgsql
AS $$
DECLARE
  result numeric;
BEGIN

  with foo as (
    select unnest (inputs) as bar
  )
  select stddev (bar)
  into result
  from foo;

  return result;
end
$$;
