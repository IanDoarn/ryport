create function "_count_e_times_something3"(text[], integer[]) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
    something1s alias for $1;
    something3s alias for $2;
    max_i int;
    i int;
    rec record;
    num int := 0;
  BEGIN
     max_i := array_upper(something1s, 1);
  
     for i in 1..max_i
     LOOP
        num := num + length(regexp_replace(something1s[i], '[^e]+', '', 'g')) *
           something3s[i]::int;
     END LOOP;
     RETURN num;
  END;
$$;
