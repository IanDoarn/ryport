create function make_date(year integer, month integer, day integer) returns date
LANGUAGE SQL
AS $$
SELECT format('%s-%s-%s', year, month, day)::date;
$$;
