create function supertrim(input_text text) returns text
LANGUAGE plperl
AS $$
  my ($input) = @_;
  $input =~ s/^\s+//;
  $input =~ s/\s+$//;

  return $input;
  
$$;
