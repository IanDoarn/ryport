create function str_join(character varying, character varying[]) returns character varying
LANGUAGE plperl
AS $$
    my ($x, $y) = @_;

    return join $x, grep { /./ } @$y;
$$;
