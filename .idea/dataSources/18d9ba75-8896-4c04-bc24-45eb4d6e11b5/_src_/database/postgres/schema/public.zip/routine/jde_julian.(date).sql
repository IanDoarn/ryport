create function jde_julian(jdedate date) returns integer
LANGUAGE plpgsql
AS $$
declare
  result integer;
begin

  result := case
    when jdedate is null or jdedate = '1900-01-01' then 0
    else
      (extract (year from jdedate) - 1900) * 1000 + extract (doy from jdedate)
  end;

  return result;
end;
$$;
